<?php

class Services_Twilio_Rest_Pricing_VoiceCountry
    extends Services_Twilio_PricingInstanceResource {
}