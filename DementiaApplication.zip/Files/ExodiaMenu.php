<?php

    require './twilio-php/Services/Twilio.php';
 
    // Twilio REST API version
    $version = "2010-04-01";
 
    // Set our Account SID and AuthToken
    $sid = 'AC98762ae2e1348e39b1eca927a3d50887';
    $token = '1d4565c9142b13f15ded1d845eda6374';
     
    // A phone number you have previously validated with Twilio
    $phonenumber = '+18558067844';
     
    // Instantiate a new Twilio Rest Client
    $client = new Services_Twilio($sid, $token, $version);
header("content-type: text/xml");
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		//http://54.173.189.142
?>

<Response>
<Say>WELCOME TO EXODIA. </Say>
    <Say> Calling caregiver </Say>
	<Dial>+16475375963</Dial>
	<Say> Calling family member </Say>
	<Dial>>+14168207274</Dial>
	<Say>Texting family and caregiver. Goodbye.</Say>
	<Redirect>http://54.173.189.142/sendsms.php</Redirect>
</Response>