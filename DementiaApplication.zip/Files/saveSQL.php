<?php
if(isset($_FILES['file'])){
  $audio = file_get_contents($_FILES['file']['tmp_name']);
 
  require_once __DIR__ . "/db.php";
  $sql = $dbh->prepare("INSERT INTO `blobdemo` (`message`) VALUES(?)");
  $sql->execute(array($audio));
 
  $sql = $dbh->query("SELECT `id` FROM `blobdemo` ORDER BY `id` DESC LIMIT 1");
  $id = $sql->fetchColumn();
 
  echo "play.php?id=$id";
}