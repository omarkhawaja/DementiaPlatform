


<?php

header("Access-Control-Allow-Origin: *");
use Phalcon\Mvc\Micro;

$servername = "aquila.clk8ghgbilss.us-west-2.rds.amazonaws.com:3306";
$username = "hackathon";
$password = "hackathon";
$dbname = "Aquila";
$conn;
try
{
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}
 catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

try {
	$app = new Micro();
	$app->get('/api/getTable/{tblname}', function ($tblname) use($app, $conn) {
	
	try{
		//$tablename = mysql_real_escape_string($tblname);
		$stmt = $conn->prepare("SELECT * FROM ". $tblname);
		//echo $tablename;
		$stmt->execute();
		$result = $stmt->fetchAll();
		echo json_encode($result);
	} catch (Exception $e){ echo 'Error: ' . $e->getMessage();}
	
	//echo $conn->getAttribute(constant("PDO::ATTR_CONNECTION_STATUS"));
	});
	
	$app->get('/api/getAudio/{audidi}', function ($audidi) use ($app, $conn) {
		try{
		
		  $sql = $conn->prepare("SELECT `message`, LENGTH(`message`) FROM `blobdemo` WHERE `id` = ?");
		  $sql->execute(array($audidi));
		  $result = $sql->fetch();

		  $audio = $result[0];
		  $size = $result[1];
		 
		  echo $audio;
		
		}catch(Exception $e){echo 'Error: ' . $e->getMessage();}
		
});
	
	$app->get('/api/getTip', function () use ($app, $conn) {
		try{
		
		  $sql = $conn->prepare("SELECT tip FROM Tips WHERE id = ?");
		  $sql->execute(array(rand(1, 30)));
		  $result = $sql->fetch();

		  $tip = $result[0];
		 
		  echo $tip;
		
		}catch(Exception $e){echo 'Error: ' . $e->getMessage();}
		
});
	/* $app->get('/api/getAudio/{audid}', function ($audid) use ($app, $conn){
		
		$stmt = $conn->prepare("SELECT longblob FROM blobdemo WHERE id= :audioid;")
		$audioid = $audid;
		$stmt->bindParam(':audioid', $audioid);
		$stmt->execute();
		
		$result = $stmt->fetchAll();
		echo $result;
	}); */
	
$app->handle();
	
	
	//$data = array();
    //foreach ($robots as $robot) {
    //    $data[] = array(
    //        'id'   => $robot->id,
    //        'name' => $robot->name
    //    );
    //}

    //echo json_encode($data);
	
}catch (Exception $e) 
{
        //echo 'Error: ' . $e->getMessage();
    }	


?>