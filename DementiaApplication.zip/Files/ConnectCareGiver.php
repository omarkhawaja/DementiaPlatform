<?php
 

	    header("content-type: text/xml");
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	
?>
<Response>
    <Dial>+16475375963</Dial>
    <Say>The call failed or the remote party hung up. Goodbye.</Say>
</Response>

	