<?php
    // if the caller pressed anything but 1 send them back
    if($_REQUEST['Digits'] != '5') {
		
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		echo("<Response>\n");
		echo("<Dial>+16475375963</Dial>\n");
		echo("<Say>The call failed or the remote party hung up. Goodbye.</Say>\n");
		echo("</Response>");
		
	}
     else
	 {
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		echo "<Response>\n";
		echo "<Say>Thank you for completing the task</Say>\n";
		echo "</Response>";
	 }
   
?>