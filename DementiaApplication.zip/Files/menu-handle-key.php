<?php
	
    // if the caller pressed anything but 1 send them back
    if($_REQUEST['Digits'] == '1') {
		/* $call = $client->account->calls->create(
            $phonenumber, // The number of the phone initiating the call
            '+14168207274', // The number of the phone receiving call
            'http://54.173.189.142/HelloWorld.php' // The URL Twilio will request when the call is answered
        ); */
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		echo("<Response>");
		echo("<Dial>+16475375963</Dial>");
		echo("<Say>Calling caregiver.</Say>");
		echo("</Response>");
		
	}
	else if ($_REQUEST['Digits'] == '2')
	{
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		echo("<Response>");
		echo("<Dial>+14168207274</Dial>");
		echo("<Say>Calling family member.</Say>");
		echo("</Response>");
	}
     else
	 {
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		echo "<Response>";
		echo "<Say>You did not choose 1 or 2. Goodbye.</Say>";
		echo "</Response>";
	 }
   
?>