<?php
/**
 * $_POST['audio'] is the Base64 encoded value of audio (WAV/MP3)
 */

 // Include the Twilio PHP library
    require './twilio-php/Services/Twilio.php';
 
    // Twilio REST API version
    $version = "2010-04-01";
 
    // Set our Account SID and AuthToken
    $sid = 'AC98762ae2e1348e39b1eca927a3d50887';
    $token = '1d4565c9142b13f15ded1d845eda6374';
     
    // A phone number you have previously validated with Twilio
    $phonenumber = '+18558067844';
     
    // Instantiate a new Twilio Rest Client
    $client = new Services_Twilio($sid, $token, $version);
 
    try {
        // Initiate a new outbound call
        $sms = $client->account->messages->sendMessage(
 
        // Step 6: Change the 'From' number below to be a valid Twilio number 
        // that you've purchased, or the (deprecated) Sandbox number
            $phonenumber, 
 
            // the number we are sending to - Any phone number
            "+16475375963",
 
            // the sms body
            "Hey you missed a call from the patient!"
        );
		$sms = $client->account->messages->sendMessage(
 
        // Step 6: Change the 'From' number below to be a valid Twilio number 
        // that you've purchased, or the (deprecated) Sandbox number
            $phonenumber, 
 
            // the number we are sending to - Any phone number
            "+14168207274",
 
            // the sms body
            "Hey you missed a call from the patient!"
        );
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
 
?>