<?php
$dsn = 'mysql:host=aquila.clk8ghgbilss.us-west-2.rds.amazonaws.com;dbname=Aquila';
$username = 'hackathon';
$password = 'hackathon';
$options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
); 

$dbh = new PDO($dsn, $username, $password, $options);
?>